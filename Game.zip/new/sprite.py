import runpy
import time
from random import randint
import pygame
from ball import Balls


pygame.init()
pygame.time.set_timer(pygame.USEREVENT, 1000)
BLACK = (0, 0, 0)
W, H = 850, 500
pygame.mixer.music.load("music/Contra.mp3")#загрузка звуковой дорожки
pygame.mixer.music.play(-1)#проигрывание мелодии
s_catch = pygame.mixer.Sound('music/Sonic Ring-Coin Collect - Sound Effect for editing.mp3')

sc = pygame.display.set_mode((W, H))

clock = pygame.time.Clock()
FPS = 60

start = 9500 # время таймера в секундах
timer_scroll = pygame.image.load('image/scroll.png').convert_alpha()
Tf = pygame.font.SysFont('arial', 40)
score = pygame.image.load('image/scroll.png').convert_alpha()
f = pygame.font.SysFont('arial', 40)


telega = pygame.image.load('image/telega.png').convert_alpha()
t_rect = telega.get_rect(centerx=W//2, bottom= H-5)# начальное размещение персонажа на экране
telega_left = pygame.transform.flip(telega, 1, 0)#направление персонажа в лево
telega_right = pygame.transform.flip(telega, 0, 0)#направление персонажа в право


balls_data = ({'path': 'image/vodka.png', 'score': 100 },
              {'path': 'image/rom.png', 'score': 150 },
              {'path': 'image/med.png', 'score': 200 },
              {'path': 'image/pumpkin.png', 'score': -100})

balls_surf = [pygame.image.load(data['path']).convert_alpha() for data in balls_data]

def creatBall (group):
    indx = randint(0, len(balls_surf)-1)
    x = randint(20, W-20)
    speed = randint(1, 5)
    return Balls(x, speed, balls_surf[indx],balls_data[indx]['score'], group)

game_score = 0
def collideBalls(): # функция отслживат ловлю шаров
    global game_score
    for ball in balls:
        if t_rect.collidepoint(ball.rect.center):
            s_catch.play()
            game_score+=ball.score
            ball.kill()



balls = pygame.sprite.Group()
bg = pygame.image.load('image/plyazh.jpg').convert()
speed = 10

total_score=0
Ts = pygame.font.SysFont('arial', 40)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
        elif event.type == pygame.USEREVENT:
            creatBall(balls)
    start -= 1

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        t_rect.x-=speed
        telega = telega_left
        if t_rect.x<0:
            t_rect.x=0

    elif keys[pygame.K_RIGHT]:
        t_rect.x+=speed
        telega = telega_right
        if t_rect.x>W+t_rect.width-370:
            t_rect.x=W-t_rect.width



    collideBalls()
    sc.blit(bg,(0, 0))#отрисовка задника
    sc.blit(score,(0, 0))#отрисовка свитка очков
    sc.blit(timer_scroll, (650,0))#отрисовка свитка таймера
    sc_timer = Tf.render(str(start), 1, (255, 0 ,0))
    sc_text = f.render(str(game_score), 1, (0, 0, 255))
    sc.blit(sc_timer, (700, 10))#отрисовка таймера
    sc.blit(sc_text, (20, 10))#отрисовка очков
    balls.draw(sc)
    sc.blit(telega, t_rect)#отрисовка персонажа


    if start <= 0:# действие когда закончится время
        start=int(start == 0)# что бы счётчик времени не стал ниже 0
        total_score = game_score
        font = pygame.font.SysFont('arial', 25)
        totalscoretext = "Набранно очков:"
        text1 = font.render(totalscoretext, 1, (255, 0, 0))
        endingtext1 = "Нормально затарился"#текст победы
        endtext1 = font.render(endingtext1, 1, (255, 0, 0))
        endingtext2 = "Сегодня снова идём за шавухой, без запивки"
        endtext2 = font.render(endingtext2, 1, (255, 0, 0))
        endingtext3 = "Всё фигня давай по новой"
        endtext3 = font.render(endingtext3, 1, (255, 192, 203))
        totalscoretimer = Ts.render(str(total_score), 1, (255, 0, 0))



        pygame.event.wait()#остановка

        sc.fill(BLACK)
        sc.blit(totalscoretimer, ((W//2)-10, (H//2)))

        pygame.mixer.music.stop()
        sc.blit(text1, ((W//2)-90, (H//2)-30))
        if total_score > 12000:
            pygame.display.update()
            time.sleep(0.7)
            sc.blit(endtext1, ((W//2)-90, (H//2)+40))
        elif total_score < 0:
            pygame.display.update()
            time.sleep(0.7)
            sc.blit(endtext3, ((W//2)-350, (H//2)+40))
            pygame.display.update()
            time.sleep(5.0)
            runpy.run_module('menu.py')
        else:
            pygame.display.update()
            time.sleep(0.7)
            sc.blit(endtext2, ((W//2)-250, (H//2)+40))
            pygame.display.update()
            time.sleep(5.0)
            runpy.run_module('menu.py')



        #running = False

    pygame.display.update()

    clock.tick(FPS)
    balls.update(H)
