import pygame.image
from pygame import *
import runpy

pygame.init()

size = (800, 600)
screen = display.set_mode(size)
title_theme = pygame.image.load('image/space.jpg').convert_alpha()
ARIAL_30 = font.SysFont('arial', 50)
pygame.mixer.music.load("music/killer instinct theme song (256  kbps).mp3")
pygame.mixer.music.play(-1)

class Menu:
    def __init__(self):
        self._options = []
        self._callbacks = []
        self._current_option_index = 0

    def append_option(self, option, callback):
        self._options.append(ARIAL_30.render(option, True, (255, 255, 255)))
        self._callbacks.append(callback)

    def switch(self, direction):
        self._current_option_index = max(0, min(self._current_option_index + direction, len(self._options) - 1))

    def select(self):
        self._callbacks[self._current_option_index]()

    def draw(self, surf, x, y, option_y_padding):
        for i, option in enumerate(self._options):
            option_rect: Rect = option.get_rect()
            option_rect.topleft = (x, y + i * option_y_padding)
            if i == self._current_option_index:
                draw.rect(surf, (255, 44, 242), option_rect)
            surf.blit(option, option_rect)


running = True


def quit_game():
    global running
    running = False


menu = Menu()
menu.append_option('Start game', lambda : runpy.run_module('Loading screen.py') )
menu.append_option('Quit', quit_game)

while running:
    for e in event.get():
        if e.type == QUIT:
            quit_game()
        if e.type == KEYDOWN:
            if e.key == K_UP:
                menu.switch(-1)
            elif e.key == K_DOWN:
                menu.switch(1)
            elif e.key == K_RETURN:
                menu.select()

    screen.fill((0, 0, 0))
    screen.blit(title_theme, (0, 0))
    menu.draw(screen, 250, 450, 55)

    display.flip()
