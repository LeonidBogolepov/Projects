import PIL
from PIL import Image
img1 = Image.open('space.jpg')
new_size = (1050, 600)
img1.thumbnail(new_size)
img1.save('space1.jpg')