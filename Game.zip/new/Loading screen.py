import time

import pygame, sys ,threading
import runpy
pygame.init()
W = 800
H = 600
size = (W, H)
screen = pygame.display.set_mode(size)

FONT = pygame.font.SysFont('arial', 50)

CLOCK = pygame.time.Clock()

WORK = 100000000

LOADING_BG = pygame.image.load("image/Loading Bar Background.png")
LOADING_BG_RECT = LOADING_BG.get_rect(center = (380, 260))
loading_bar = pygame.image.load("image/Loading Bar.png")
loading_bar_rect = loading_bar.get_rect(midleft=(0, 260))
loading_finished = False
loading_progress = 0
loading_bar_width = 8
def doWork():
    global loading_finished, loading_progress
    for i in range( WORK):
        math_equation = 523687/789456 * 89456
        loading_progress = i
    loading_finished =True


finished = FONT.render('Loaded', True, 'white')
finished_rect = finished.get_rect(center = ((W//2)-30, 100))

threading.Thread(target=doWork).start()


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.fill((0,0,0))
    if not loading_finished:
        loading_bar_width = loading_progress/WORK * 720
        loading_bar = pygame.transform.scale(loading_bar, (int(loading_bar_width), 150))
        loading_bar_rect = loading_bar.get_rect(midleft = (20, 260))
        screen.blit(LOADING_BG, LOADING_BG_RECT)
        screen.blit(loading_bar, loading_bar_rect)
    else:
        screen.blit(finished, finished_rect)
        pygame.display.update()
        time.sleep(3.0)
        runpy.run_module('intro.py')

    pygame.display.update()
    CLOCK.tick(60)


