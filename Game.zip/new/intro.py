import pygame
import runpy

pygame.init()

W, H = 850, 500
size = (W, H)
screen = pygame.display.set_mode(size)
pygame.mixer.music.load("music/TMNT3.mp3")
pygame.mixer.music.play(1)
title_theme = pygame.image.load('image/kosmos.jpg').convert_alpha()
title_theme = pygame.transform.smoothscale(title_theme, (850, 350))
font = pygame.font.SysFont('arial', 25)
text1 = "Ready Stady Go"
#text2 = 'как вдруг из пролетающего самолёта выпал...'
#text3 = "Он решил не обламываться и затарится халявой..."
text1 = font.render(text1, 1 , (255, 255, 255))
#text2 = font.render(text2, 1 , (255, 255, 255))
#text3 = font.render(text3, 1 , (255, 255, 255))





running_intro = True
while running_intro:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
        keys = pygame.key.get_pressed()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                runpy.run_module('sprite.py')

    screen.fill((0, 0, 0))
    screen.blit(title_theme, (0, 0))
    screen.blit(text1, (50, 350))
    #screen.blit(text2, (50, 390))
    #screen.blit(text3, (50, 430))
    pygame.display.update()

